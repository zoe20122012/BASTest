sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("BASTest.Risks.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);